import"../chunks/DsnmJJEf.js";import{H as b,N as $,o as g,I as v,J as u,P as y,b6 as ae,m as C,n as w,a$ as D,M as U,aB as K,av as A,aC as oe,O as j,C as _,V,bh as ne,a3 as se,aD as de,Q as Z,w as q,U as ve,$ as ue,v as re}from"../chunks/J53a5pXB.js";import{s as z,b as M,e as me,i as ge,t as he,k as fe}from"../chunks/DwDLloZq.js";import{p as I,i as N,l as T,s as O,a as B,b as W}from"../chunks/CVWE5XDX.js";import"../chunks/B6xteeIL.js";import{i as be}from"../chunks/Ce3FM-Or.js";import{s as ie,e as pe,U as _e,u as Y,a as ye}from"../chunks/DE1mMIYW.js";import{s as P}from"../chunks/CORCjSxP.js";import{I as L,X as $e}from"../chunks/D9OV0qr6.js";import{s as we,g as le}from"../chunks/qLTqb0RQ.js";import{s as ke}from"../chunks/CK65x0Z5.js";var ze=b('<div class="brand-text svelte-1lkfz9o"><div>Happy Balance</div> <div class="brand-tagline text-xs text-subtle svelte-1lkfz9o">Financial harmony</div></div>'),Se=b('<div class="flex items-center gap-3"><div><img src="/logo/happy-balance-logo-without-text.png" alt="Happy Balance Logo"/></div> <!></div>');function Q(r,e){let t=I(e,"showText",3,!0),s=I(e,"size",3,"md");const o={sm:"h-8 w-8",md:"h-10 w-10",lg:"h-12 w-12"},i={sm:"text-sm",md:"text-base",lg:"text-lg"};var a=Se(),n=v(a),l=v(n);u(n);var c=y(n,2);{var m=d=>{var p=ze(),S=v(p);ae(2),u(p),$(()=>z(S,1,`brand-name ${i[s()]??""}`,"svelte-1lkfz9o")),g(d,p)};N(c,d=>{t()&&d(m)})}u(a),$(()=>{z(n,1,`brand-icon ${o[s()]??""}`,"svelte-1lkfz9o"),z(l,1,`logo-image ${o[s()]??""}`,"svelte-1lkfz9o")}),g(r,a)}function Ce(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["path",{d:"m15 18-6-6 6-6"}]];L(r,O({name:"chevron-left"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function xe(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["path",{d:"m9 18 6-6-6-6"}]];L(r,O({name:"chevron-right"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Me(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1"}]];L(r,O({name:"layout-dashboard"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Ne(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["path",{d:"M4 12h16"}],["path",{d:"M4 18h16"}],["path",{d:"M4 6h16"}]];L(r,O({name:"menu"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Ie(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"}]];L(r,O({name:"moon"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Te(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["path",{d:"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"}],["path",{d:"M12 17.5v-11"}]];L(r,O({name:"receipt"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Oe(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"}],["circle",{cx:"12",cy:"12",r:"3"}]];L(r,O({name:"settings"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Pe(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["circle",{cx:"12",cy:"12",r:"4"}],["path",{d:"M12 2v2"}],["path",{d:"M12 20v2"}],["path",{d:"m4.93 4.93 1.41 1.41"}],["path",{d:"m17.66 17.66 1.41 1.41"}],["path",{d:"M2 12h2"}],["path",{d:"M20 12h2"}],["path",{d:"m6.34 17.66-1.41 1.41"}],["path",{d:"m19.07 4.93-1.41 1.41"}]];L(r,O({name:"sun"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Le(r,e){const t=T(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const s=[["path",{d:"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"}],["circle",{cx:"7.5",cy:"7.5",r:".5",fill:"currentColor"}]];L(r,O({name:"tag"},()=>t,{get iconNode(){return s},children:(o,i)=>{var a=C(),n=w(a);P(n,e,"default",{},null),g(o,a)},$$slots:{default:!0}}))}function Ue(r,e,t){const s=_(e)?"light":"dark";if(ie(s),_(t)){const o=document.querySelector(".theme-toggle");o?.classList.add("theme-toggle--active"),setTimeout(()=>{o?.classList.remove("theme-toggle--active")},200)}}var je=b('<div class="theme-toggle__loading svelte-whvnjs"></div>'),Je=b('<button><div class="theme-toggle__icon svelte-whvnjs"><!></div></button>');function G(r,e){U(e,!0);const t=()=>W(pe,"$effectiveTheme",s),[s,o]=B();let i=I(e,"size",3,"md"),a=I(e,"collapsed",3,!1),n=oe(!1);const l={sm:16,md:18};let c=A(()=>t()==="dark");K(()=>{V(n,!0)});var m=Je();let d;m.__click=[Ue,c,n];var p=v(m),S=v(p);{var J=f=>{var k=C(),F=w(k);{var E=x=>{Pe(x,{get size(){return l[i()]},strokeWidth:2})},H=x=>{Ie(x,{get size(){return l[i()]},strokeWidth:2})};N(F,x=>{_(c)?x(E):x(H,!1)})}g(f,k)},h=f=>{var k=je();g(f,k)};N(S,f=>{_(n)?f(J):f(h,!1)})}u(p),u(m),$(f=>{d=z(m,1,`theme-toggle theme-toggle--${i()??""}`,"svelte-whvnjs",d,f),M(m,"aria-label",_(c)?"Switch to light mode":"Switch to dark mode"),M(m,"title",_(c)?"Switch to light mode":"Switch to dark mode"),m.disabled=!_(n)},[()=>({"theme-toggle--collapsed":a()})]),g(r,m),j(),o()}D(["click"]);var De=b("<button><!></button>");function ee(r,e){let t=I(e,"size",3,"md");const s={sm:"w-8 h-8",md:"w-10 h-10"};var o=De();o.__click=function(...l){e.onclick?.apply(this,l)};var i=v(o);{var a=l=>{{let c=A(()=>t()==="sm"?16:18);xe(l,{get size(){return _(c)},strokeWidth:2})}},n=l=>{{let c=A(()=>t()==="sm"?16:18);Ce(l,{get size(){return _(c)},strokeWidth:2})}};N(i,l=>{e.collapsed?l(a):l(n,!1)})}u(o),$(()=>{z(o,1,`sidebar-toggle ${s[t()]??""}`,"svelte-9cegbt"),M(o,"aria-label",e.collapsed?"Expand sidebar":"Collapse sidebar"),M(o,"title",e.collapsed?"Expand sidebar":"Collapse sidebar")}),g(r,o)}D(["click"]);var Fe=b('<div class="sidebar-brand svelte-1f4vrzv"><!></div> <div class="sidebar-controls svelte-1f4vrzv"><!> <!></div>',1),He=b('<div class="sidebar-collapsed-header svelte-1f4vrzv"><!> <!></div>'),Ae=b("<header><!></header>");function We(r,e){var t=Ae();let s;var o=v(t);{var i=n=>{var l=Fe(),c=w(l),m=v(c);Q(m,{size:"md"}),u(c);var d=y(c,2),p=v(d);G(p,{size:"sm"});var S=y(p,2);ee(S,{get collapsed(){return e.collapsed},get onclick(){return e.onToggle},size:"sm"}),u(d),g(n,l)},a=n=>{var l=He(),c=v(l);ee(c,{get collapsed(){return e.collapsed},get onclick(){return e.onToggle},size:"md"});var m=y(c,2);G(m,{size:"sm",collapsed:!0}),u(l),g(n,l)};N(o,n=>{e.collapsed?n(a,!1):n(i)})}u(t),$(n=>s=z(t,1,"sidebar-header svelte-1f4vrzv",null,s,n),[()=>({"sidebar-header--collapsed":e.collapsed})]),g(r,t)}function qe(r,e){e.onclick&&e.onclick()}var Ee=b('<div class="nav-item__badge svelte-1612dzz"></div>'),Ke=b('<a><div class="nav-item__icon svelte-1612dzz"><!></div> <span class="nav-item__label svelte-1612dzz"><!></span> <!></a>');function Be(r,e){U(e,!0);let t=I(e,"isActive",3,!1),s=I(e,"isImportant",3,!1);const i={"layout-dashboard":Me,receipt:Te,tag:Le,settings:Oe}[e.icon];var a=Ke();let n;a.__click=[qe,e];var l=v(a),c=v(l);{var m=h=>{i(h,{size:18,strokeWidth:2})};N(c,h=>{i&&h(m)})}u(l);var d=y(l,2),p=v(d);ne(p,()=>e.children??se),u(d);var S=y(d,2);{var J=h=>{var f=Ee();g(h,f)};N(S,h=>{s()&&h(J)})}u(a),$(h=>{M(a,"href",e.href),n=z(a,1,"nav-item svelte-1612dzz",null,n,h),M(a,"aria-current",t()?"page":void 0)},[()=>({"nav-item--active":t(),"nav-item--important":s()})]),g(r,a),j()}D(["click"]);const Re=()=>{const r=we;return{page:{subscribe:r.page.subscribe},navigating:{subscribe:r.navigating.subscribe},updated:r.updated}},Ve={subscribe(r){return Re().page.subscribe(r)}};function Ge(r,e){e.onItemClick&&e.onItemClick(),le("/import")}var Qe=b('<div class="import-section svelte-1jp01bf"><div class="import-divider svelte-1jp01bf"></div> <button class="import-btn svelte-1jp01bf"><svg class="import-icon svelte-1jp01bf" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg> <span class="import-text svelte-1jp01bf"> </span></button></div>'),Xe=b("<nav><!> <!></nav>");function ce(r,e){U(e,!0);const t=()=>W(Ve,"$page",o),s=()=>W(he,"$t",o),[o,i]=B();let a=I(e,"isMobile",3,!1),n=I(e,"collapsed",3,!1);const l=[{href:"/",icon:"layout-dashboard",labelKey:"navigation.dashboard"},{href:"/transactions",icon:"receipt",labelKey:"navigation.transactions"},{href:"/categories",icon:"tag",labelKey:"navigation.categories"},{href:"/settings",icon:"settings",labelKey:"navigation.settings"}];let c=A(()=>t().url.pathname);var m=Xe();let d;var p=v(m);me(p,17,()=>l,ge,(h,f)=>{{let k=A(()=>_(c)===_(f).href);Be(h,{get href(){return _(f).href},get icon(){return _(f).icon},get collapsed(){return n()},get isActive(){return _(k)},get onclick(){return e.onItemClick},children:(F,E)=>{ae();var H=de();$(x=>Z(H,x),[()=>n()?"":s()(_(f).labelKey)]),g(F,H)},$$slots:{default:!0}})}});var S=y(p,2);{var J=h=>{var f=Qe(),k=y(v(f),2);k.__click=[Ge,e];var F=y(v(k),2),E=v(F,!0);u(F),u(k),u(f),$((H,x)=>{M(k,"title",H),Z(E,x)},[()=>s()("navigation.import"),()=>s()("navigation.import")]),g(h,f)};N(S,h=>{n()||h(J)})}u(m),$(h=>d=z(m,1,"nav-list svelte-1jp01bf",null,d,h),[()=>({"nav-list--mobile":a(),"nav-list--collapsed":n()})]),g(r,m),j(),i()}D(["click"]);var Ze=b("<nav><!></nav>");function Ye(r,e){var t=Ze();let s;var o=v(t);ce(o,{get collapsed(){return e.collapsed}}),u(t),$(i=>s=z(t,1,"sidebar-navigation svelte-1o11pgg",null,s,i),[()=>({"sidebar-navigation--collapsed":e.collapsed})]),g(r,t)}function et(){le("/import")}var tt=b('<footer class="sidebar-footer sidebar-footer--collapsed svelte-1lc1c15"><button class="import-button import-button--icon svelte-1lc1c15" aria-label="Import transactions" title="Import transactions"><!></button></footer>');function at(r,e){U(e,!0);var t=C(),s=w(t);{var o=i=>{var a=tt(),n=v(a);n.__click=[et];var l=v(n);_e(l,{size:18,strokeWidth:2}),u(n),u(a),g(i,a)};N(s,i=>{e.collapsed&&i(o)})}g(r,t),j()}D(["click"]);const R=q(!1);function ot(){R.update(r=>{const e=!r;return localStorage.setItem("sidebar-collapsed",JSON.stringify(e)),document.body.classList.toggle("sidebar-collapsed",e),e})}function nt(){{const r=localStorage.getItem("sidebar-collapsed");if(r!==null){const e=JSON.parse(r);R.set(e),document.body.classList.toggle("sidebar-collapsed",e)}}}var st=b('<aside><div class="sidebar-container svelte-1nwtzae"><!> <!> <!></div></aside>');function rt(r,e){U(e,!1);const t=()=>W(R,"$sidebarCollapsed",s),[s,o]=B();K(()=>{nt()}),be();var i=st();let a;var n=v(i),l=v(n);We(l,{get collapsed(){return t()},get onToggle(){return ot}});var c=y(l,2);Ye(c,{get collapsed(){return t()}});var m=y(c,2);at(m,{get collapsed(){return t()}}),u(n),u(i),$(d=>a=z(i,1,"sidebar svelte-1nwtzae",null,a,d),[()=>({"sidebar--collapsed":t()})]),g(r,i),j(),o()}var it=b('<div class="mobile-overlay svelte-6ew3r8" aria-hidden="true"></div>'),lt=b('<!> <aside><div class="mobile-sidebar-container svelte-6ew3r8"><header class="mobile-sidebar-header svelte-6ew3r8"><!> <button class="mobile-sidebar-close svelte-6ew3r8" aria-label="Close menu"><!></button></header> <nav class="mobile-sidebar-navigation svelte-6ew3r8"><!></nav></div></aside>',1);function ct(r,e){U(e,!0);function t(h){h.key==="Escape"&&e.isOpen&&e.onClose()}var s=lt();ve("keydown",ue,t);var o=w(s);{var i=h=>{var f=it();f.__click=function(...k){e.onClose?.apply(this,k)},g(h,f)};N(o,h=>{e.isOpen&&h(i)})}var a=y(o,2);let n;var l=v(a),c=v(l),m=v(c);Q(m,{size:"md"});var d=y(m,2);d.__click=function(...h){e.onClose?.apply(this,h)};var p=v(d);$e(p,{size:20,strokeWidth:2}),u(d),u(c);var S=y(c,2),J=v(S);ce(J,{collapsed:!1,get onItemClick(){return e.onClose}}),u(S),u(l),u(a),$(h=>{n=z(a,1,"mobile-sidebar svelte-6ew3r8",null,n,h),M(a,"aria-hidden",!e.isOpen)},[()=>({"mobile-sidebar--open":e.isOpen})]),g(r,s),j()}D(["click"]);var dt=b('<header><div class="mobile-header-content svelte-c8w1m7"><div class="mobile-header-start svelte-c8w1m7"><button class="mobile-menu-toggle svelte-c8w1m7"><!></button> <!></div> <div class="mobile-header-end svelte-c8w1m7"><!></div></div></header>');function vt(r,e){var t=dt();let s;var o=v(t),i=v(o),a=v(i);a.__click=function(...d){e.onMenuToggle?.apply(this,d)};var n=v(a);Ne(n,{size:22,strokeWidth:2}),u(a);var l=y(a,2);Q(l,{showText:!1,size:"sm"}),u(i);var c=y(i,2),m=v(c);G(m,{size:"sm"}),u(c),u(o),u(t),$(d=>{s=z(t,1,"mobile-header svelte-c8w1m7",null,s,d),M(a,"aria-label",e.isMenuOpen?"Close menu":"Open menu"),M(a,"aria-expanded",e.isMenuOpen)},[()=>({"mobile-header--blur":e.isMenuOpen})]),g(r,t)}D(["click"]);var ut=b("<!> <!> <!>",1);function mt(r,e){U(e,!0);let t=oe(!1);function s(){V(t,!_(t))}function o(){V(t,!1)}K(()=>{const c=m=>{if(!_(t))return;const d=document.querySelector(".mobile-sidebar"),p=document.querySelector(".mobile-header");d&&p&&!d.contains(m.target)&&!p.contains(m.target)&&o()};return document.addEventListener("click",c),()=>document.removeEventListener("click",c)});var i=ut(),a=w(i);rt(a,{});var n=y(a,2);vt(n,{onMenuToggle:s,get isMenuOpen(){return _(t)}});var l=y(n,2);ct(l,{get isOpen(){return _(t)},onClose:o}),g(r,i),j()}function gt(){const{subscribe:r,set:e,update:t}=q([]);return{subscribe:r,async load(){try{const s=localStorage.getItem("transactions");if(s){const o=JSON.parse(s);e(o);return}}catch(s){console.warn("Failed to load from localStorage:",s)}e([])},async add(s){const o={...s,id:crypto.randomUUID?.()||`tx-${Date.now()}-${Math.random()}`,createdAt:new Date};try{const i=JSON.parse(localStorage.getItem("transactions")||"[]"),a=[o,...i];return localStorage.setItem("transactions",JSON.stringify(a)),t(n=>[o,...n]),o}catch(i){return console.warn("Failed to save to localStorage:",i),t(a=>[o,...a]),o}},async update(s,o){t(i=>{const a=i.map(n=>n.id===s?{...n,...o}:n);try{localStorage.setItem("transactions",JSON.stringify(a))}catch(n){console.warn("Failed to save to localStorage:",n)}return a})},async delete(s){t(o=>{const i=o.filter(a=>a.id!==s);try{localStorage.setItem("transactions",JSON.stringify(i))}catch(a){console.warn("Failed to save to localStorage:",a)}return i})},async bulkUpdate(s,o){t(i=>{const a=i.map(n=>s.includes(n.id)?{...n,...o}:n);try{localStorage.setItem("transactions",JSON.stringify(a))}catch(n){console.warn("Failed to save to localStorage:",n)}return a})},async applyCategoryToPattern(s,o){const i=te(s);t(a=>{const n=a.map(l=>te(l)===i?{...l,categoryId:o}:l);try{localStorage.setItem("transactions",JSON.stringify(n))}catch(l){console.warn("Failed to save to localStorage:",l)}return n})}}}function ht(){const{subscribe:r,set:e,update:t}=q([{id:"1",name:"Food & Groceries",type:"essential",color:"#f5796c",icon:"🍽️"},{id:"2",name:"Transport",type:"essential",color:"#7abaa5",icon:"🚇"},{id:"3",name:"Entertainment",type:"discretionary",color:"#fecd2c",icon:"🎬"},{id:"4",name:"Utilities",type:"essential",color:"#023c46",icon:"⚡"},{id:"5",name:"Income",type:"income",color:"#7abaa5",icon:"💰"},{id:"6",name:"Investment",type:"investment",color:"#023c46",icon:"📈"}]);return{subscribe:r,async add(s){const o={...s,id:crypto.randomUUID?.()||`cat-${Date.now()}-${Math.random()}`};return t(i=>[...i,o]),o},async update(s,o){t(i=>i.map(a=>a.id===s?{...a,...o}:a))}}}function ft(){const{subscribe:r,set:e,update:t}=q([]);return{subscribe:r,async load(){e([])},async add(s){const o={...s,id:crypto.randomUUID?.()||`rule-${Date.now()}-${Math.random()}`};return t(i=>[...i,o]),o}}}function te(r){const e=`${r.merchant.toLowerCase()}_${r.description.toLowerCase().replace(/\d+/g,"").replace(/\s+/g,"_").trim()}`;let t=0;for(let s=0;s<e.length;s++){const o=e.charCodeAt(s);t=(t<<5)-t+o,t=t&t}return t.toString(36)}const X=gt();ht();ft();const bt=q(new Set);re([X,bt],([r,e])=>({all:r,selected:r.filter(t=>e.has(t.id))}));re(X,r=>{const e=r.filter(o=>o.amount>0).reduce((o,i)=>o+i.amount,0),t=r.filter(o=>o.amount<0).reduce((o,i)=>o+Math.abs(i.amount),0),s=e-t;return{income:e,expenses:t,balance:s,transactionCount:r.length}});var pt=b('<div class="app-shell svelte-12qhfyh"><!> <main><div class="content-container svelte-12qhfyh"><!></div></main></div>');function It(r,e){U(e,!0);const t=()=>W(R,"$sidebarCollapsed",s),[s,o]=B();K(async()=>{await Y.load(),Y.subscribe(d=>{fe(d.language),ke(d.currency),ie(d.theme),ye(d.theme)}),typeof window<"u"&&!window.__transactions_loaded__&&(X.load(),window.__transactions_loaded__=!0)});var i=pt(),a=v(i);mt(a,{});var n=y(a,2);let l;var c=v(n),m=v(c);ne(m,()=>e.children??se),u(c),u(n),u(i),$(d=>l=z(n,1,"main-content svelte-12qhfyh",null,l,d),[()=>({"main-content--collapsed":t()})]),g(r,i),j(),o()}export{It as component};
