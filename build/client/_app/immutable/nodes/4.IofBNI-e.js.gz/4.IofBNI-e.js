import"../chunks/DsnmJJEf.js";import{m as de,n as Y,o as S,M as oe,b5 as ce,H as M,I as s,P as A,J as l,C as t,W as J,N as Q,Q as Z,O as ne,V as x,U as j,u as I,D as P,R as ke,T as Ce,b6 as He,$ as Ee,b0 as Oe,ac as ye,aB as Ge,b7 as Ke,b8 as Ve,av as Ie}from"../chunks/J53a5pXB.js";import{b as je}from"../chunks/CNdUi1S-.js";import{l as xe,s as Ae,p as i,i as ee,a as Qe,b as be}from"../chunks/CVWE5XDX.js";import{c as pe,a as De}from"../chunks/CDx50ljX.js";import{b as le,s as fe,d as Be,c as Je,e as he,i as Te,r as _e,f as Xe,t as Ye}from"../chunks/DwDLloZq.js";import{c as $e,a as Ze}from"../chunks/CK65x0Z5.js";import"../chunks/B6xteeIL.js";import{b as we,a as Me}from"../chunks/p_RlkIA4.js";import{i as se}from"../chunks/Ce3FM-Or.js";import{c as et}from"../chunks/CeGYYBmx.js";import{s as ge}from"../chunks/CORCjSxP.js";import{I as ze,X as Pe}from"../chunks/D9OV0qr6.js";import{P as tt,s as at}from"../chunks/DxdlsFuA.js";import{b as ot,c as Ne}from"../chunks/k9KbQBG2.js";import{C as nt}from"../chunks/Cd9j2BcX.js";import{T as rt,C as Ue}from"../chunks/CddshGW2.js";import{T as lt,a as st,W as ct}from"../chunks/gZbhgo-S.js";function it(H,e){const o=xe(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const d=[["path",{d:"m16 3 4 4-4 4"}],["path",{d:"M20 7H4"}],["path",{d:"m8 21-4-4 4-4"}],["path",{d:"M4 17h16"}]];ze(H,Ae({name:"arrow-right-left"},()=>o,{get iconNode(){return d},children:(m,_)=>{var c=de(),a=Y(c);ge(a,e,"default",{},null),S(m,c)},$$slots:{default:!0}}))}function dt(H,e){const o=xe(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const d=[["circle",{cx:"8",cy:"8",r:"6"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18"}],["path",{d:"M7 6h1v4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82"}]];ze(H,Ae({name:"coins"},()=>o,{get iconNode(){return d},children:(m,_)=>{var c=de(),a=Y(c);ge(a,e,"default",{},null),S(m,c)},$$slots:{default:!0}}))}function ut(H,e){const o=xe(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const d=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 16v-4"}],["path",{d:"M12 8h.01"}]];ze(H,Ae({name:"info"},()=>o,{get iconNode(){return d},children:(m,_)=>{var c=de(),a=Y(c);ge(a,e,"default",{},null),S(m,c)},$$slots:{default:!0}}))}function vt(H,e){const o=xe(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const d=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"}]];ze(H,Ae({name:"pen"},()=>o,{get iconNode(){return d},children:(m,_)=>{var c=de(),a=Y(c);ge(a,e,"default",{},null),S(m,c)},$$slots:{default:!0}}))}var gt=M('<div class="helper-tooltip svelte-fkb8iw"><button class="helper-button svelte-fkb8iw" aria-label="Show help information"><!></button></div>'),ft=M('<button class="add-button svelte-fkb8iw"><!></button>'),mt=M('<div><p class="tooltip-text svelte-fkb8iw"> </p></div>'),pt=M('<div class="section-header svelte-fkb8iw"><div class="section-title svelte-fkb8iw"><!> <h2 class="svelte-fkb8iw"> </h2> <span class="category-count svelte-fkb8iw"> </span> <!></div> <!></div> <!>',1);function yt(H,e){oe(e,!1);let o=i(e,"title",8),d=i(e,"icon",8),m=i(e,"categoryCount",8,0),_=i(e,"showAddButton",8,!0),c=i(e,"showHelper",8,!1),a=i(e,"helperText",8,""),v=J(!1),u=J(null),y=J({top:0,left:0,position:"bottom"});const D=ce();function $(){D("add")}function N(k){const f=k.getBoundingClientRect(),h=320,R=80,U=8,W=window.innerHeight,K=window.innerWidth,O=f.top,te=W-f.bottom;let G,re,ae;return te>=R+U?(ae="bottom",G=f.bottom+U):O>=R+U||O>te?(ae="top",G=f.top-R-U):(ae="bottom",G=f.bottom+U),re=Math.max(U,Math.min(f.left+f.width/2-h/2,K-h-U)),{top:G,left:re,position:ae}}function B(){t(u)&&x(y,N(t(u))),x(v,!0)}function p(){x(v,!1)}se();var E=pt(),T=Y(E),r=s(T),g=s(r);et(g,d,(k,f)=>{f(k,{size:16})});var b=A(g,2),q=s(b,!0);l(b);var L=A(b,2),w=s(L,!0);l(L);var C=A(L,2);{var F=k=>{var f=gt(),h=s(f),R=s(h);ut(R,{size:14}),l(h),je(h,U=>x(u,U),()=>t(u)),l(f),j("mouseenter",h,B),j("mouseleave",h,p),j("focus",h,B),j("blur",h,p),S(k,f)};ee(C,k=>{c()&&k(F)})}l(r);var V=A(r,2);{var X=k=>{var f=ft(),h=s(f);tt(h,{size:14}),l(f),Q(R=>le(f,"aria-label",`Add new ${R??""} category`),[()=>(P(o()),I(()=>o().toLowerCase()))]),j("click",f,$),S(k,f)};ee(V,k=>{_()&&k(X)})}l(T);var n=A(T,2);{var z=k=>{var f=mt();let h;var R=s(f),U=s(R,!0);l(R),l(f),Q(W=>{h=fe(f,1,"custom-tooltip svelte-fkb8iw",null,h,W),Be(f,`
      top: ${t(y),I(()=>t(y).top)??""}px;
      left: ${t(y),I(()=>t(y).left)??""}px;
    `),Z(U,a())},[()=>({"position-top":t(y).position==="top"})]),S(k,f)};ee(n,k=>{t(v)&&c()&&a()&&k(z)})}Q(()=>{Z(q,o()),Z(w,m())}),S(H,E),ne()}var ht=M("<div> </div>");function Fe(H,e){oe(e,!1);const o=J();let d=i(e,"icon",8),m=i(e,"color",8,"#7ABAA5"),_=i(e,"size",8,"md"),c=i(e,"clickable",8,!1),a=i(e,"selected",8,!1);const v={sm:"w-6 h-6 text-sm",md:"w-10 h-10 text-xl",lg:"w-12 h-12 text-2xl"};ke(()=>(P(_()),P(c()),P(a())),()=>{x(o,["category-icon",v[_()],c()&&"clickable",a()&&"selected"].filter(Boolean).join(" "))}),Ce(),se();var u=ht(),y=s(u,!0);l(u),Q(()=>{fe(u,1,Je(t(o)),"svelte-1q4nuoe"),Be(u,`background-color: ${m()??""}20`),le(u,"role",c()?"button":void 0),le(u,"tabindex",c()?0:void 0),Z(y,d())}),j("click",u,function(D){we.call(this,e,D)}),j("keydown",u,function(D){we.call(this,e,D)}),S(H,u),ne()}var bt=M("<button></button>"),_t=M('<div class="color-picker svelte-1ijw1q8"></div>');function wt(H,e){oe(e,!1);let o=i(e,"selectedColor",12,"#7ABAA5"),d=i(e,"availableColors",24,()=>["#7ABAA5","#FC8181","#63B3ED","#68D391","#F6AD55","#A78BFA","#FBB6CE","#9CA3AF"]);const m=ce();function _(a){o(a),m("colorSelected",{color:a})}se();var c=_t();he(c,5,d,Te,(a,v)=>{var u=bt();let y;Q(D=>{y=fe(u,1,"color-option svelte-1ijw1q8",null,y,D),Be(u,`background-color: ${t(v)??""}`),le(u,"aria-label",`Select color ${t(v)??""}`)},[()=>({selected:o()===t(v)})]),j("click",u,()=>_(t(v))),S(a,u)}),l(c),S(H,c),ne()}var kt=M('<div class="budget-section svelte-1v89c5a"><label class="budget-label svelte-1v89c5a"> </label> <div class="budget-input-group svelte-1v89c5a"><span class="currency-symbol svelte-1v89c5a"> </span> <input type="number" class="budget-input svelte-1v89c5a"/> <span class="budget-period svelte-1v89c5a">/ año</span></div></div>');function Ct(H,e){oe(e,!1);let o=i(e,"value",12,0),d=i(e,"currencySymbol",8,"€"),m=i(e,"placeholder",8,"0"),_=i(e,"label",8,"Presupuesto anual");const c=ce();function a(p){const E=p.target,T=parseFloat(E.value)||0;o(T),c("valueChange",{value:T})}se();var v=kt(),u=s(v),y=s(u,!0);l(u);var D=A(u,2),$=s(D),N=s($,!0);l($);var B=A($,2);_e(B),He(2),l(D),l(v),Q(()=>{Z(y,_()),Z(N,d()),le(B,"placeholder",m()),Xe(B,o())}),j("input",B,a),j("keydown",B,function(p){we.call(this,e,p)}),S(H,v),ne()}var xt=M('<button role="option"> </button>'),At=M('<div class="icon-picker-backdrop svelte-1el26sj"></div> <div class="icon-picker-overlay svelte-1el26sj" role="dialog" aria-modal="true" aria-label="Select icon"><div class="icon-picker-header svelte-1el26sj"><span class="icon-picker-title svelte-1el26sj">Seleccionar icono</span> <button class="icon-picker-close svelte-1el26sj" aria-label="Close icon selector"><!></button></div> <div class="icon-picker-content svelte-1el26sj" role="listbox"></div></div>',1);function Bt(H,e){oe(e,!1);let o=i(e,"show",8,!1),d=i(e,"selectedIcon",12,"📄"),m=i(e,"availableIcons",24,()=>["🏠","🍽️","🚗","🎮","💰","📚","🏥","🛒","✈️","🎬","☕","🎯","💡","🏋️","🎨","🛍️","👔","⚡","💊","🔧","📱","🎵","🌮","🍕","🏦","⛽","🚇","🚌","🏪","💻","📺","👟","🍺","🍎","🥬","🧘","📊","💳","🏆","🎊","🌍","📸","🎪","🏖️","🎂","🍔","🌟","🔥"]),_=i(e,"position",24,()=>({top:0,left:0,maxHeight:"none"}));const c=ce();function a(p){d(p),c("iconSelected",{icon:p}),c("close")}function v(){c("close")}function u(p){if(p.key==="Escape"){v();return}["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(p.key)&&(y(p),p.preventDefault())}function y(p){const E=document.activeElement;if(!E?.classList.contains("icon-option"))return;const T=Array.from(document.querySelectorAll(".icon-option")),r=T.indexOf(E),g=4;let b=r;switch(p.key){case"ArrowLeft":b=r>0?r-1:T.length-1;break;case"ArrowRight":b=r<T.length-1?r+1:0;break;case"ArrowUp":b=r>=g?r-g:T.length-g+r%g,b>=T.length&&(b=r);break;case"ArrowDown":b=r+g<T.length?r+g:r%g;break}b!==r&&T[b]&&T[b].focus()}function D(){setTimeout(()=>{const p=document.querySelector(".icon-option");p&&p.focus()},50)}ke(()=>P(o()),()=>{o()&&D()}),Ce(),se();var $=de();j("keydown",Ee,u);var N=Y($);{var B=p=>{var E=At(),T=Y(E),r=A(T,2),g=s(r),b=A(s(g),2),q=s(b);Pe(q,{size:14}),l(b),l(g);var L=A(g,2);he(L,5,m,Te,(w,C)=>{var F=xt();let V;var X=s(F,!0);l(F),Q(n=>{V=fe(F,1,"icon-option svelte-1el26sj",null,V,n),le(F,"aria-selected",d()===t(C)),le(F,"aria-label",`Select icon ${t(C)??""}`),Z(X,t(C))},[()=>({selected:d()===t(C)})]),j("click",F,()=>a(t(C))),S(w,F)}),l(L),l(r),Q(()=>Be(r,`
      top: ${P(_()),I(()=>_().top)??""}px;
      left: ${P(_()),I(()=>_().left)??""}px;
      max-height: ${P(_()),I(()=>_().maxHeight)??""};
    `)),j("click",T,v),j("click",b,v),S(p,E)};ee(N,p=>{o()&&p(B)})}S(H,$),ne()}var Tt=M('<div class="category-icon-container svelte-1vt4lp8"><!></div> <div class="category-details svelte-1vt4lp8"><input type="text" class="category-name-input svelte-1vt4lp8" placeholder="Nombre de la categoría"/> <!> <!></div> <div class="category-actions svelte-1vt4lp8"><button class="save-btn svelte-1vt4lp8" aria-label="Save category"><!></button> <button class="cancel-btn svelte-1vt4lp8" aria-label="Cancel editing"><!></button></div>',1),zt=M('<span class="category-budget svelte-1vt4lp8"> </span>'),St=M('<span class="category-budget no-budget svelte-1vt4lp8">Sin presupuesto</span>'),It=M('<!> <div class="category-info svelte-1vt4lp8"><h3 class="category-name svelte-1vt4lp8"> </h3> <!></div> <div class="category-actions svelte-1vt4lp8"><button class="action-btn svelte-1vt4lp8"><!></button> <button class="action-btn delete svelte-1vt4lp8"><!></button></div>',1),Dt=M("<div><!></div> <!>",1);function We(H,e){oe(e,!1);let o=i(e,"category",8,null),d=i(e,"isEditing",8,!1),m=i(e,"isNew",8,!1),_=i(e,"currencySymbol",8,"€"),c=i(e,"formatCurrency",8),a=i(e,"editForm",28,()=>({name:"",icon:"📄",color:"#7ABAA5",annualBudget:0,type:"essential"})),v=J(!1),u=J({top:0,left:0,maxHeight:"none"});const y=ce();function D(){o()&&y("edit",{category:o()})}function $(){o()&&y("delete",{category:o()})}function N(){y("save",{formData:a()})}function B(){y("cancel")}function p(n){const z=n.getBoundingClientRect(),k=200,f=280,h=8,R=window.innerHeight,U=window.innerWidth,W=R-z.bottom,K=z.top;let O,te,G;return W>=f?(O=z.bottom+h,G=Math.min(280,W-h*2)):K>=f?(G=Math.min(280,K-h*2),O=z.top-G-h-50):K>W?(G=Math.max(150,K-h*2),O=h):(O=z.bottom+h,G=Math.max(150,W-h*2)),te=Math.max(h,Math.min(z.left,U-k-h)),{top:O,left:te,maxHeight:`${G}px`}}function E(n){const z=n.currentTarget;x(u,p(z)),x(v,!t(v))}function T({detail:n}){a(a().icon=n.icon,!0),x(v,!1)}function r({detail:n}){a(a().color=n.color,!0)}function g({detail:n}){a(a().annualBudget=n.value,!0)}function b(n){n.key==="Enter"&&(d()||m())&&N(),n.key==="Escape"&&(d()||m())&&B()}se();var q=Dt();j("keydown",Ee,b);var L=Y(q);let w;var C=s(L);{var F=n=>{var z=Tt(),k=Y(z),f=s(k);Fe(f,{get icon(){return P(a()),I(()=>a().icon)},get color(){return P(a()),I(()=>a().color)},size:"md",clickable:!0,$$events:{click:E}}),l(k);var h=A(k,2),R=s(h);_e(R),Oe(R,m());var U=A(R,2);Ct(U,{get value(){return P(a()),I(()=>a().annualBudget)},get currencySymbol(){return _()},$$events:{valueChange:g}});var W=A(U,2);wt(W,{get selectedColor(){return P(a()),I(()=>a().color)},$$events:{colorSelected:r}}),l(h);var K=A(h,2),O=s(K),te=s(O);nt(te,{size:14}),l(O);var G=A(O,2),re=s(G);Pe(re,{size:14}),l(G),l(K),ot(R,()=>a().name,ae=>a(a().name=ae,!0)),j("click",O,N),j("click",G,B),S(n,z)},V=n=>{var z=de(),k=Y(z);{var f=h=>{var R=It(),U=Y(R);Fe(U,{get icon(){return P(o()),I(()=>o().icon)},get color(){return P(o()),I(()=>o().color)},size:"md"});var W=A(U,2),K=s(W),O=s(K,!0);l(K);var te=A(K,2);{var G=ve=>{var me=zt(),qe=s(me);l(me),Q(Le=>Z(qe,`${Le??""} / año`),[()=>(P(c()),P(o()),I(()=>c()(o().annualBudget)))]),S(ve,me)},re=ve=>{var me=St();S(ve,me)};ee(te,ve=>{P(o()),I(()=>o().annualBudget)?ve(G):ve(re,!1)})}l(W);var ae=A(W,2),ie=s(ae),Se=s(ie);vt(Se,{size:14}),l(ie);var ue=A(ie,2),Re=s(ue);rt(Re,{size:14}),l(ue),l(ae),Q(()=>{Z(O,(P(o()),I(()=>o().name))),le(ie,"aria-label",`Edit category ${P(o()),I(()=>o().name)??""}`),le(ue,"aria-label",`Delete category ${P(o()),I(()=>o().name)??""}`)}),j("click",ie,D),j("click",ue,$),S(h,R)};ee(k,h=>{o()&&h(f)},!0)}S(n,z)};ee(C,n=>{d()||m()?n(F):n(V,!1)})}l(L);var X=A(L,2);Bt(X,{get selectedIcon(){return P(a()),I(()=>a().icon)},get position(){return t(u)},get show(){return t(v)},set show(n){x(v,n)},$$events:{iconSelected:T,close:()=>x(v,!1)},$$legacy:!0}),Q(n=>w=fe(L,1,"category-card svelte-1vt4lp8",null,w,n),[()=>({editing:d()||m()})]),S(H,q),ne()}var Ht=M('<section class="category-section svelte-1wys565"><!> <div class="category-list svelte-1wys565"><!> <!></div></section>');function Et(H,e){oe(e,!1);let o=i(e,"title",8),d=i(e,"icon",8),m=i(e,"categories",24,()=>[]),_=i(e,"showHelper",8,!1),c=i(e,"helperText",8,""),a=i(e,"currencySymbol",8,"€"),v=i(e,"formatCurrency",8),u=i(e,"categoryType",8),y=J(!1),D=J({name:"",icon:"📄",color:"#7ABAA5",annualBudget:0,type:u()}),$=J(null),N=J({name:"",icon:"",color:"",annualBudget:0,type:u()});const B=ce();function p(){x(y,!0),x(D,{name:"",icon:"📄",color:"#7ABAA5",annualBudget:0,type:u()})}function E({detail:n}){const z={name:n.formData.name,icon:n.formData.icon,color:n.formData.color,type:n.formData.type,annualBudget:n.formData.annualBudget};B("categoryAdd",{category:z}),x(y,!1)}function T(){x(y,!1)}function r({detail:n}){x($,n.category.id),x(N,{name:n.category.name,icon:n.category.icon,color:n.category.color,annualBudget:n.category.annualBudget||0,type:n.category.type})}function g({detail:n}){t($)&&(B("categoryUpdate",{categoryId:t($),updates:n.formData}),x($,null))}function b(){x($,null)}function q({detail:n}){B("categoryDelete",{category:n.category})}se();var L=Ht(),w=s(L);{let n=ye(()=>!t(y));yt(w,{get title(){return o()},get icon(){return d()},get categoryCount(){return P(m()),I(()=>m().length)},get showAddButton(){return t(n)},get showHelper(){return _()},get helperText(){return c()},$$events:{add:p}})}var C=A(w,2),F=s(C);{var V=n=>{We(n,{isNew:!0,get currencySymbol(){return a()},get formatCurrency(){return v()},get editForm(){return t(D)},set editForm(z){x(D,z)},$$events:{save:E,cancel:T},$$legacy:!0})};ee(F,n=>{t(y)&&n(V)})}var X=A(F,2);he(X,1,m,n=>n.id,(n,z)=>{{let k=ye(()=>(t($),t(z),I(()=>t($)===t(z).id)));We(n,{get category(){return t(z)},get isEditing(){return t(k)},get currencySymbol(){return a()},get formatCurrency(){return v()},get editForm(){return t(N)},set editForm(f){x(N,f)},$$events:{edit:r,delete:q,save:g,cancel:b},$$legacy:!0})}}),l(C),l(L),S(H,L),ne()}var Pt=M('<h3 id="modal-title" class="modal-title svelte-17e0w4c"> </h3>'),$t=M('<button class="close-button svelte-17e0w4c" aria-label="Close modal"><!></button>'),Mt=M('<div class="modal-header svelte-17e0w4c"><!> <!></div>'),Nt=M('<div class="modal-backdrop svelte-17e0w4c"><div role="dialog" aria-modal="true"><!> <div class="modal-body svelte-17e0w4c"><!></div> <div class="modal-footer svelte-17e0w4c"><!></div></div></div>');function Ft(H,e){oe(e,!1);let o=i(e,"show",8,!1),d=i(e,"title",8,""),m=i(e,"size",8,"md"),_=i(e,"closable",8,!0),c=i(e,"backdrop",8,!0);const a=ce(),v={sm:"max-w-sm",md:"max-w-md",lg:"max-w-lg"};function u(){c()&&_()&&a("close")}function y(B){B.key==="Escape"&&_()&&a("close")}ke(()=>P(o()),()=>{if(o()){document.body.style.overflow,document.body.style.paddingRight;const B=window.innerWidth-document.documentElement.clientWidth;document.body.style.overflow="hidden",document.body.style.paddingRight=`${B}px`}else document.body.style.overflow="",document.body.style.paddingRight=""}),Ce(),se();var D=de();j("keydown",Ee,y);var $=Y(D);{var N=B=>{var p=Nt(),E=s(p),T=s(E);{var r=w=>{var C=Mt(),F=s(C);{var V=z=>{var k=Pt(),f=s(k,!0);l(k),Q(()=>Z(f,d())),S(z,k)};ee(F,z=>{d()&&z(V)})}var X=A(F,2);{var n=z=>{var k=$t(),f=s(k);Pe(f,{size:20}),l(k),j("click",k,()=>a("close")),S(z,k)};ee(X,z=>{_()&&z(n)})}l(C),S(w,C)};ee(T,w=>{(d()||_())&&w(r)})}var g=A(T,2),b=s(g);ge(b,e,"default",{},null),l(g);var q=A(g,2),L=s(q);ge(L,e,"footer",{},null),l(q),l(E),l(p),Q(()=>{fe(E,1,`modal-container ${P(m()),I(()=>v[m()])??""}`,"svelte-17e0w4c"),le(E,"aria-labelledby",d()?"modal-title":void 0)}),j("click",E,at(function(w){we.call(this,e,w)})),j("click",p,u),S(B,p)};ee($,B=>{o()&&B(N)})}S(H,D),ne()}var Wt=M('<label class="recategorize-option svelte-1ku0enw"><input type="radio" name="recategorize" class="svelte-1ku0enw"/> <span class="category-option-display svelte-1ku0enw"><span class="category-icon-small svelte-1ku0enw"> </span> <span> </span></span></label>'),jt=M('<div class="recategorize-section svelte-1ku0enw"><div class="transaction-count svelte-1ku0enw"><!> <span> </span></div> <p class="recategorize-label svelte-1ku0enw">¿Qué deseas hacer con ellas?</p> <div class="recategorize-options svelte-1ku0enw"><label class="recategorize-option svelte-1ku0enw"><input type="radio" name="recategorize" class="svelte-1ku0enw"/> <span>Dejar sin categoría</span></label> <!></div></div>'),Ut=M('<p class="no-transactions svelte-1ku0enw">Esta categoría no tiene transacciones asociadas.</p>'),Rt=M('<div class="delete-content svelte-1ku0enw"><p class="delete-warning svelte-1ku0enw">¿Estás seguro de eliminar la categoría <strong class="svelte-1ku0enw"> </strong>?</p> <!></div>'),qt=M('<div slot="footer" class="modal-footer svelte-1ku0enw"><button class="cancel-button svelte-1ku0enw">Cancelar</button> <button class="delete-button svelte-1ku0enw">Eliminar</button></div>');function Lt(H,e){oe(e,!1);const o=[];let d=i(e,"show",12,!1),m=i(e,"category",8,null),_=i(e,"transactionCount",8,0),c=i(e,"alternativeCategories",24,()=>[]),a=J("none");const v=ce();function u(){m()&&v("confirm",{categoryId:m().id,recategorizeTarget:t(a)})}function y(){v("cancel")}ke(()=>P(d()),()=>{d()&&x(a,"none")}),Ce(),se(),Ft(H,{title:"Eliminar categoría",get show(){return d()},set show(D){d(D)},$$events:{close:y},children:(D,$)=>{var N=de(),B=Y(N);{var p=E=>{var T=Rt(),r=s(T),g=A(s(r)),b=s(g,!0);l(g),He(),l(r);var q=A(r,2);{var L=C=>{var F=jt(),V=s(F),X=s(V);Ue(X,{size:16});var n=A(X,2),z=s(n);l(n),l(V);var k=A(V,4),f=s(k),h=s(f);_e(h),h.value=h.__value="remove",He(2),l(f);var R=A(f,2);he(R,1,c,Te,(U,W)=>{var K=Wt(),O=s(K);_e(O);var te,G=A(O,2),re=s(G),ae=s(re,!0);l(re);var ie=A(re,2),Se=s(ie,!0);l(ie),l(G),l(K),Q(()=>{te!==(te=(t(W),I(()=>t(W).id)))&&(O.value=(O.__value=(t(W),I(()=>t(W).id)))??""),Z(ae,(t(W),I(()=>t(W).icon))),Z(Se,(t(W),I(()=>t(W).name)))}),Ne(o,[],O,()=>(t(W),I(()=>t(W).id),t(a)),ue=>x(a,ue)),S(U,K)}),l(k),l(F),Q(()=>Z(z,`Hay ${_()??""} transacción${_()!==1?"es":""} con esta categoría`)),Ne(o,[],h,()=>t(a),U=>x(a,U)),S(C,F)},w=C=>{var F=Ut();S(C,F)};ee(q,C=>{_()>0?C(L):C(w,!1)})}l(T),Q(()=>Z(b,(P(m()),I(()=>m().name)))),S(E,T)};ee(B,E=>{m()&&E(p)})}S(D,N)},$$slots:{default:!0,footer:(D,$)=>{var N=qt(),B=s(N),p=A(B,2);l(N),j("click",B,y),j("click",p,u),S(D,N)}},$$legacy:!0}),ne()}var Ot=M('<div class="categories-page svelte-17kgxv3"><header class="page-header svelte-17kgxv3"><div class="header-content svelte-17kgxv3"><h1 class="page-title svelte-17kgxv3">Configuración de Categorías</h1> <p class="page-subtitle svelte-17kgxv3">Gestiona tus categorías y presupuestos anuales</p></div></header> <main class="categories-container svelte-17kgxv3"></main></div> <!>',1);function Gt(H,e){oe(e,!1);let o=i(e,"categoryTypes",24,()=>[]),d=i(e,"categoriesByType",24,()=>({income:[],essential:[],discretionary:[],investment:[],debt_payment:[],no_compute:[]})),m=i(e,"currencySymbol",8,"€"),_=i(e,"formatCurrency",8),c=J(!1),a=J(null),v=J(0),u=J([]);const y=ce();function D({detail:w}){y("categoryAdd",{category:w.category})}function $({detail:w}){y("categoryUpdate",{categoryId:w.categoryId,updates:w.updates})}function N({detail:w}){x(a,w.category),y("getTransactionCount",{categoryId:w.category.id}),y("getAlternativeCategories",{category:w.category}),x(c,!0)}function B({detail:w}){y("categoryDelete",{categoryId:w.categoryId,recategorizeTarget:w.recategorizeTarget}),x(c,!1),x(a,null),x(v,0),x(u,[])}function p(){x(c,!1),x(a,null),x(v,0),x(u,[])}function E(w){x(v,w)}function T(w){x(u,w)}var r={setTransactionCount:E,setAlternativeCategories:T};se();var g=Ot(),b=Y(g),q=A(s(b),2);he(q,5,o,Te,(w,C)=>{const F=ye(()=>(P(d()),t(C),I(()=>d()[t(C).value]||[])));{let V=ye(()=>(t(C),I(()=>t(C).showHelper||!1))),X=ye(()=>(t(C),I(()=>t(C).helperText||"")));Et(w,{get title(){return t(C),I(()=>t(C).label)},get icon(){return t(C),I(()=>t(C).icon)},get categories(){return t(F)},get categoryType(){return t(C),I(()=>t(C).value)},get showHelper(){return t(V)},get helperText(){return t(X)},get currencySymbol(){return m()},get formatCurrency(){return _()},$$events:{categoryAdd:D,categoryUpdate:$,categoryDelete:N}})}}),l(q),l(b);var L=A(b,2);return Lt(L,{get category(){return t(a)},get transactionCount(){return t(v)},get alternativeCategories(){return t(u)},get show(){return t(c)},set show(w){x(c,w)},$$events:{confirm:B,cancel:p},$$legacy:!0}),S(H,g),Me(e,"setTransactionCount",E),Me(e,"setAlternativeCategories",T),ne(r)}function ua(H,e){oe(e,!0);const o=()=>be(pe,"$apiCategories",c),d=()=>be(Ye,"$t",c),m=()=>be(Ze,"$currentCurrency",c),_=()=>be(De,"$apiTransactions",c),[c,a]=Qe();let v,u=Ie(()=>()=>{const r={income:[],essential:[],discretionary:[],investment:[],debt_payment:[],no_compute:[]};return o().forEach(g=>{r[g.type]&&r[g.type].push(g)}),r}),y=Ie(()=>[{value:"income",label:d()("categories.types.income"),icon:lt},{value:"investment",label:d()("categories.types.investment"),icon:st},{value:"essential",label:d()("categories.types.essential"),icon:ct},{value:"discretionary",label:d()("categories.types.discretionary"),icon:dt},{value:"debt_payment",label:d()("categories.types.debt_payment"),icon:Ue},{value:"no_compute",label:d()("categories.types.no_compute"),icon:it,showHelper:!0,helperText:d()("categories.helpers.no_compute")}]);function D(r){const g=$e[m()];return new Intl.NumberFormat(g.locale,{style:"currency",currency:g.code}).format(r)}function $(){return $e[m()].symbol}async function N({detail:r}){await pe.add(r.category)}async function B({detail:r}){await pe.update(r.categoryId,r.updates)}async function p({detail:r}){const g=o().find(b=>b.id===r.categoryId);if(g){if(r.recategorizeTarget!=="none"){const b=_().filter(q=>q.categoryId===g.id);for(const q of b)await De.update(q.id,{categoryId:r.recategorizeTarget==="remove"?void 0:r.recategorizeTarget})}await pe.delete(r.categoryId)}}function E({detail:r}){const b=_().filter(q=>q.categoryId===r.categoryId).length;v.setTransactionCount(b)}function T({detail:r}){const g=o().filter(b=>b.id!==r.category.id&&b.type===r.category.type);v.setAlternativeCategories(g)}Ge(async()=>{await pe.load(),await De.load()}),Ke(r=>{Ve.title="Categorías - Happy Balance"});{let r=Ie($);je(Gt(H,{get categoryTypes(){return t(y)},get categoriesByType(){return t(u)},get currencySymbol(){return t(r)},formatCurrency:D,$$events:{categoryAdd:N,categoryUpdate:B,categoryDelete:p,getTransactionCount:E,getAlternativeCategories:T}}),g=>v=g,()=>v)}ne(),a()}export{ua as component};
