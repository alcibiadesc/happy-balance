import"../chunks/DsnmJJEf.js";import"../chunks/B6xteeIL.js";import{m as Y,n as V,o as D,M as ae,R as ce,T as ye,O as ne,D as y,V as r,W as U,H as j,I as b,C as l,P as S,J as w,N as F,Q as W,a$ as De,ac as M,u as x,aD as Ne,b6 as $e,b5 as Re,b7 as je,b8 as Pe,aB as ze}from"../chunks/J53a5pXB.js";import{i as ge}from"../chunks/Ce3FM-Or.js";import{l as re,s as oe,p as a,i as X,a as He,b as me}from"../chunks/CVWE5XDX.js";import{s as te,r as Je,g as Fe,e as Ue,i as We,h as Ve,j as Be,k as we,t as Ke,l as qe}from"../chunks/DwDLloZq.js";import{c as Oe,s as Ie,a as Ge}from"../chunks/CK65x0Z5.js";import{U as Qe,e as Ze,u as G,s as Ce,t as Xe}from"../chunks/DE1mMIYW.js";import{c as Ye}from"../chunks/CDx50ljX.js";import{b as Le}from"../chunks/Bt-Xh7oU.js";import{C as xe}from"../chunks/NJjUsxgD.js";import{c as Te}from"../chunks/CeGYYBmx.js";import{s as Q}from"../chunks/CORCjSxP.js";import{I as se}from"../chunks/D9OV0qr6.js";import{C as et,T as tt}from"../chunks/CddshGW2.js";function at(d,e){const i=re(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335"}],["path",{d:"m9 11 3 3L22 4"}]];se(d,oe({name:"circle-check-big"},()=>i,{get iconNode(){return c},children:(s,u)=>{var n=Y(),o=V(n);Q(o,e,"default",{},null),D(s,n)},$$slots:{default:!0}}))}function nt(d,e){const i=re(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["line",{x1:"12",x2:"12",y1:"2",y2:"22"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"}]];se(d,oe({name:"dollar-sign"},()=>i,{get iconNode(){return c},children:(s,u)=>{var n=Y(),o=V(n);Q(o,e,"default",{},null),D(s,n)},$$slots:{default:!0}}))}function rt(d,e){const i=re(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M12 15V3"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["path",{d:"m7 10 5 5 5-5"}]];se(d,oe({name:"download"},()=>i,{get iconNode(){return c},children:(s,u)=>{var n=Y(),o=V(n);Q(o,e,"default",{},null),D(s,n)},$$slots:{default:!0}}))}function ot(d,e){const i=re(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4"}],["path",{d:"M10 9H8"}],["path",{d:"M16 13H8"}],["path",{d:"M16 17H8"}]];se(d,oe({name:"file-text"},()=>i,{get iconNode(){return c},children:(s,u)=>{var n=Y(),o=V(n);Q(o,e,"default",{},null),D(s,n)},$$slots:{default:!0}}))}function Ee(d,e){const i=re(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"}],["path",{d:"M2 12h20"}]];se(d,oe({name:"globe"},()=>i,{get iconNode(){return c},children:(s,u)=>{var n=Y(),o=V(n);Q(o,e,"default",{},null),D(s,n)},$$slots:{default:!0}}))}function st(d,e){const i=re(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z"}],["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor"}]];se(d,oe({name:"palette"},()=>i,{get iconNode(){return c},children:(s,u)=>{var n=Y(),o=V(n);Q(o,e,"default",{},null),D(s,n)},$$slots:{default:!0}}))}function lt(d,e){const i=re(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"}],["path",{d:"M3 3v5h5"}]];se(d,oe({name:"rotate-ccw"},()=>i,{get iconNode(){return c},children:(s,u)=>{var n=Y(),o=V(n);Q(o,e,"default",{},null),D(s,n)},$$slots:{default:!0}}))}var it=j("<div><!> <span> </span></div>");function Ae(d,e){ae(e,!1);const i=U();let c=a(e,"message",8,""),s=a(e,"type",8,"info"),u=a(e,"visible",8,!0),n=a(e,"icon",8,null);const o={success:at,error:et,info:ot};ce(()=>(y(n()),y(s())),()=>{r(i,n()||o[s()])}),ye();var f=Y(),C=V(f);{var T=A=>{var h=it(),g=b(h);Te(g,()=>l(i),(p,v)=>{v(p,{size:20,strokeWidth:2})});var I=S(g,2),k=b(I,!0);w(I),w(h),F(()=>{te(h,1,`status-message ${s()??""}`,"svelte-1qa3mgs"),W(k,c())}),D(A,h)};X(C,A=>{u()&&c()&&A(T)})}D(d,f),ne()}var ct=j('<div class="settings-card svelte-12ngydb"><div class="card-header svelte-12ngydb"><div><!></div> <h2 class="card-title svelte-12ngydb"> </h2></div> <div class="card-content svelte-12ngydb"><!></div></div>');function Se(d,e){let i=a(e,"title",8),c=a(e,"icon",8),s=a(e,"iconVariant",8,"appearance");var u=ct(),n=b(u),o=b(n),f=b(o);Te(f,c,(g,I)=>{I(g,{size:20,strokeWidth:2})}),w(o);var C=S(o,2),T=b(C,!0);w(C),w(n);var A=S(n,2),h=b(A);Q(h,e,"default",{},null),w(A),w(u),F(()=>{te(o,1,`card-icon ${s()??""}`,"svelte-12ngydb"),W(T,i())}),D(d,u)}var gt=j('<span class="setting-desc svelte-fjddc1"> </span>'),ut=j('<div class="setting-item svelte-fjddc1"><div class="setting-info svelte-fjddc1"><span class="setting-label svelte-fjddc1"> </span> <!></div> <div class="setting-control svelte-fjddc1"><!></div></div>');function ke(d,e){let i=a(e,"label",8),c=a(e,"description",8,"");var s=ut(),u=b(s),n=b(u),o=b(n,!0);w(n);var f=S(n,2);{var C=h=>{var g=gt(),I=b(g,!0);w(g),F(()=>W(I,c())),D(h,g)};X(f,h=>{c()&&h(C)})}w(u);var T=S(u,2),A=b(T);Q(A,e,"default",{},null),w(T),w(s),F(()=>W(o,i())),D(d,s)}var dt=j("<div> </div>"),vt=j("<div> </div>"),mt=j('<div class="toggle-container svelte-11upsh5"><!> <input type="checkbox"/> <!></div>');function ft(d,e){let i=a(e,"checked",8,!1),c=a(e,"onToggle",8,()=>{}),s=a(e,"disabled",8,!1),u=a(e,"leftIcon",8,""),n=a(e,"rightIcon",8,""),o=a(e,"leftLabel",8,""),f=a(e,"rightLabel",8,""),C=a(e,"size",8,"lg");var T=mt(),A=b(T);{var h=p=>{var v=dt(),m=b(v);w(v),F(()=>{te(v,1,`toggle-option ${i()?"":"active"}`,"svelte-11upsh5"),W(m,`${u()??""}${o()??""}`)}),D(p,v)};X(A,p=>{(u()||o())&&p(h)})}var g=S(A,2);Je(g),g.__change=[function(...p){c()?.apply(this,p)}];var I=S(g,2);{var k=p=>{var v=vt(),m=b(v);w(v),F(()=>{te(v,1,`toggle-option ${i()?"active":""}`,"svelte-11upsh5"),W(m,`${n()??""}${f()??""}`)}),D(p,v)};X(I,p=>{(n()||f())&&p(k)})}w(T),F(()=>{Fe(g,i()),g.disabled=s(),te(g,1,`toggle toggle-primary toggle-${C()??""}`,"svelte-11upsh5")}),D(d,T)}De(["change"]);function ht(d,e){ae(e,!1);let i=a(e,"isDark",8,!1),c=a(e,"onToggle",8),s=a(e,"t",8);ge();{let u=M(()=>(y(s()),x(()=>s()("settings.theme")))),n=M(()=>(y(i()),y(s()),x(()=>i()?s()("settings.themes.dark"):s()("settings.themes.light"))));ke(d,{get label(){return l(u)},get description(){return l(n)},children:(o,f)=>{ft(o,{get checked(){return i()},get onToggle(){return c()},leftIcon:"☀️",rightIcon:"🌙"})},$$slots:{default:!0}})}ne()}var pt=j('<div class="select-icon svelte-1kkwge1"><!></div>'),_t=j("<option disabled> </option>"),yt=j("<option><!> </option>"),bt=j('<div><!> <select class="select-input svelte-1kkwge1"><!><!></select></div>');function Me(d,e){let i=a(e,"options",24,()=>[]),c=a(e,"value",8,""),s=a(e,"onchange",8,()=>{}),u=a(e,"icon",8,null),n=a(e,"placeholder",8,""),o=a(e,"disabled",8,!1),f=a(e,"withIcon",8,!1);var C=bt(),T=b(C);{var A=v=>{var m=pt(),N=b(m);Te(N,u,(E,P)=>{P(E,{size:16,strokeWidth:2})}),w(m),D(v,m)};X(T,v=>{f()&&u()&&v(A)})}var h=S(T,2);h.__change=[function(...v){s()?.apply(this,v)}];var g=b(h);{var I=v=>{var m=_t(),N=b(m,!0);w(m),m.value=m.__value="",F(()=>W(N,n())),D(v,m)};X(g,v=>{n()&&v(I)})}var k=S(g);Ue(k,1,i,We,(v,m)=>{var N=yt(),E=b(N);{var P=z=>{var B=Ne();F(()=>W(B,(l(m),x(()=>l(m).icon)))),D(z,B)};X(E,z=>{l(m),x(()=>l(m).icon)&&z(P)})}var ee=S(E,1,!0);w(N);var $={};F(()=>{W(ee,(l(m),x(()=>l(m).label))),$!==($=(l(m),x(()=>l(m).value)))&&(N.value=(N.__value=(l(m),x(()=>l(m).value)))??"")}),D(v,N)}),w(h);var p;Ve(h),w(C),F(()=>{te(C,1,`select-container ${f()?"with-icon":""}`,"svelte-1kkwge1"),h.disabled=o(),p!==(p=c())&&(h.value=(h.__value=c())??"",Be(h,c()))}),D(d,C)}De(["change"]);function wt(d,e){ae(e,!1);const i=U(),c=U();let s=a(e,"languages",24,()=>[]),u=a(e,"currentLanguage",8,""),n=a(e,"onchange",8),o=a(e,"t",8);ce(()=>y(s()),()=>{r(i,s().map(f=>({value:f.code,label:f.name,icon:f.flag})))}),ce(()=>(y(s()),y(u())),()=>{r(c,s().find(f=>f.code===u())?.name||"English")}),ye(),ge();{let f=M(()=>(y(o()),x(()=>o()("settings.language"))));ke(d,{get label(){return l(f)},get description(){return l(c)},children:(C,T)=>{Me(C,{get options(){return l(i)},get value(){return u()},get onchange(){return n()},get icon(){return Ee},withIcon:!0})},$$slots:{default:!0}})}ne()}function It(d,e){ae(e,!1);const i=U();let c=a(e,"currencyOptions",24,()=>[]),s=a(e,"currentCurrency",8,""),u=a(e,"onchange",8),n=a(e,"t",8);ce(()=>(y(c()),y(s())),()=>{r(i,c().find(o=>o.value===s())?.label||"EUR")}),ye(),ge();{let o=M(()=>(y(n()),x(()=>n()("settings.currency"))));ke(d,{get label(){return l(o)},get description(){return l(i)},children:(f,C)=>{Me(f,{get options(){return c()},get value(){return s()},get onchange(){return u()}})},$$slots:{default:!0}})}ne()}var Ct=j('<div class="import-spinner svelte-oixc39"></div> Importing...',1),xt=j("<!> Import Data",1),St=j('<div class="data-actions svelte-oixc39"><button class="action-button export svelte-oixc39"><!> </button> <label><input type="file" accept=".json" style="display: none;" class="svelte-oixc39"/> <!></label> <button class="action-button reset svelte-oixc39"><!> </button> <button class="action-button delete svelte-oixc39"><!> </button></div>');function Dt(d,e){ae(e,!1);let i=a(e,"importing",8,!1),c=a(e,"onExport",8),s=a(e,"onImport",8),u=a(e,"onReset",8),n=a(e,"onDeleteAll",8),o=a(e,"t",8);ge();var f=St(),C=b(f);C.__click=function(...$){c()?.apply(this,$)};var T=b(C);rt(T,{size:16,strokeWidth:2});var A=S(T);w(C);var h=S(C,2),g=b(h);g.__change=function(...$){s()?.apply(this,$)};var I=S(g,2);{var k=$=>{var z=Ct();$e(),D($,z)},p=$=>{var z=xt(),B=V(z);Qe(B,{size:16,strokeWidth:2}),$e(),D($,z)};X(I,$=>{i()?$(k):$(p,!1)})}w(h);var v=S(h,2);v.__click=function(...$){u()?.apply(this,$)};var m=b(v);lt(m,{size:16,strokeWidth:2});var N=S(m);w(v);var E=S(v,2);E.__click=function(...$){n()?.apply(this,$)};var P=b(E);tt(P,{size:16,strokeWidth:2});var ee=S(P);w(E),w(f),F(($,z,B)=>{W(A,` ${$??""}`),te(h,1,`action-button import ${i()?"loading":""}`,"svelte-oixc39"),g.disabled=i(),W(N,` ${z??""}`),W(ee,` ${B??""}`)},[()=>(y(o()),x(()=>o()("settings.export_data"))),()=>(y(o()),x(()=>o()("settings.reset_data"))),()=>(y(o()),x(()=>o()("settings.clear_data")))]),D(d,f),ne()}De(["click","change"]);var Tt=j("<!> <!>",1),kt=j('<main class="settings-page svelte-1vtrhe0"><div class="settings-header svelte-1vtrhe0"><h1 class="page-title svelte-1vtrhe0"> </h1></div> <!> <!> <div class="settings-grid svelte-1vtrhe0"><!> <!> <!></div></main> <!> <!> <!>',1);function $t(d,e){ae(e,!1);let i=a(e,"isDark",8,!1),c=a(e,"onToggleTheme",8),s=a(e,"languages",24,()=>[]),u=a(e,"currentLanguage",8,""),n=a(e,"onLanguageChange",8),o=a(e,"currencyOptions",24,()=>[]),f=a(e,"currentCurrency",8,""),C=a(e,"onCurrencyChange",8),T=a(e,"importing",8,!1),A=a(e,"onExportData",8),h=a(e,"onImportFile",8),g=a(e,"onResetData",8),I=a(e,"onDeleteAllData",8),k=a(e,"importStatus",8,""),p=a(e,"importError",8,""),v=a(e,"importSuccess",8,!1),m=a(e,"showImportModal",12,!1),N=a(e,"showDeleteAllModal",12,!1),E=a(e,"showResetModal",12,!1),P=a(e,"pendingImportData",8,null),ee=a(e,"onConfirmImport",8),$=a(e,"onCancelImport",8),z=a(e,"onConfirmReset",8),B=a(e,"onConfirmDeleteAll",8),_=a(e,"t",8);Re(),ge();var fe=kt();je(R=>{F(J=>Pe.title=`${J??""} - Happy Balance`,[()=>(y(_()),x(()=>_()("settings.title")))])});var ue=V(fe),de=b(ue),he=b(de),be=b(he,!0);w(he),w(de);var pe=S(de,2);{let R=M(()=>v()?"success":"info"),J=M(()=>!!k());Ae(pe,{get message(){return k()},get type(){return l(R)},get visible(){return l(J)}})}var _e=S(pe,2);{let R=M(()=>!!p());Ae(_e,{get message(){return p()},type:"error",get visible(){return l(R)}})}var t=S(_e,2),O=b(t);{let R=M(()=>(y(_()),x(()=>_()("settings.theme"))));Se(O,{get title(){return l(R)},get icon(){return st},iconVariant:"appearance",children:(J,q)=>{ht(J,{get isDark(){return i()},get onToggle(){return c()},get t(){return _()}})},$$slots:{default:!0}})}var L=S(O,2);Se(L,{title:"Localization",get icon(){return Ee},iconVariant:"localization",children:(R,J)=>{var q=Tt(),ie=V(q);wt(ie,{get languages(){return s()},get currentLanguage(){return u()},get onchange(){return n()},get t(){return _()}});var ve=S(ie,2);It(ve,{get currencyOptions(){return o()},get currentCurrency(){return f()},get onchange(){return C()},get t(){return _()}}),D(R,q)},$$slots:{default:!0}});var H=S(L,2);{let R=M(()=>(y(_()),x(()=>_()("settings.data"))));Se(H,{get title(){return l(R)},get icon(){return nt},iconVariant:"data",children:(J,q)=>{Dt(J,{get importing(){return T()},get onExport(){return A()},get onImport(){return h()},get onReset(){return g()},get onDeleteAll(){return I()},get t(){return _()}})},$$slots:{default:!0}})}w(t),w(ue);var le=S(ue,2);{let R=M(()=>(y(P()),x(()=>P()?.transactions?.length||0))),J=M(()=>(y(P()),x(()=>P()?.settings?.exportDate?new Date(P().settings.exportDate).toLocaleDateString():"Unknown date")));xe(le,{title:"Import Data",get message(){return`Are you sure you want to import ${l(R)??""} transactions from ${l(J)??""}? This will merge with your existing data.`},confirmText:"Import",cancelText:"Cancel",type:"info",get onConfirm(){return ee()},get onCancel(){return $()},get isOpen(){return m()},set isOpen(q){m(q)},$$legacy:!0})}var Z=S(le,2);{let R=M(()=>(y(_()),x(()=>_()("modal.reset_title")))),J=M(()=>(y(_()),x(()=>_()("modal.reset_message")))),q=M(()=>(y(_()),x(()=>_()("modal.reset_everything")))),ie=M(()=>(y(_()),x(()=>_()("common.cancel"))));xe(Z,{get title(){return l(R)},get message(){return l(J)},get confirmText(){return l(q)},get cancelText(){return l(ie)},type:"warning",get onConfirm(){return z()},onCancel:()=>{},get isOpen(){return E()},set isOpen(ve){E(ve)},$$legacy:!0})}var K=S(Z,2);{let R=M(()=>(y(_()),x(()=>_()("modal.delete_all_title")))),J=M(()=>(y(_()),x(()=>_()("modal.delete_all_message")))),q=M(()=>(y(_()),x(()=>_()("modal.delete_everything")))),ie=M(()=>(y(_()),x(()=>_()("common.cancel"))));xe(K,{get title(){return l(R)},get message(){return l(J)},get confirmText(){return l(q)},get cancelText(){return l(ie)},type:"danger",get onConfirm(){return B()},onCancel:()=>{},get isOpen(){return N()},set isOpen(ve){N(ve)},$$legacy:!0})}F(R=>W(be,R),[()=>(y(_()),x(()=>_()("settings.title")))]),D(d,fe),ne()}function Vt(d,e){ae(e,!1);const i=()=>me(Ze,"$effectiveTheme",o),c=()=>me(Ge,"$currentCurrency",o),s=()=>me(qe,"$currentLanguage",o),u=()=>me(Xe,"$theme",o),n=()=>me(Ke,"$t",o),[o,f]=He(),C=U(),T="http://localhost:3008/api",A=Object.values(Oe).map(t=>({value:t.code,label:`${t.symbol} ${t.name}`,symbol:t.symbol})),h=[{code:"en",name:"English",flag:"🇺🇸"},{code:"es",name:"Español",flag:"🇪🇸"}];let g=U(""),I=U(""),k=U(!1),p=U(!1),v=U(!1),m=U(!1),N=U(!1),E=U(null);async function P(){const t=l(C)?"light":"dark";Ce(t),await G.updateTheme(t)}async function ee(t){const O=t.target;we(O.value),await G.updateLanguage(O.value)}async function $(t){const O=t.target;Ie(O.value),await G.updateCurrency(O.value)}function z(){const t={transactions:JSON.parse(localStorage.getItem("transactions")||"[]"),transactionHashes:JSON.parse(localStorage.getItem("transaction-hashes")||"[]"),categories:JSON.parse(localStorage.getItem("categories")||"[]"),settings:{currency:c(),language:s(),theme:u(),exportDate:new Date().toISOString(),version:"1.0.0"},metadata:{appName:"Happy Balance",exportedBy:"Settings Export",totalTransactions:JSON.parse(localStorage.getItem("transactions")||"[]").length}},O=new Blob([JSON.stringify(t,null,2)],{type:"application/json"}),L=URL.createObjectURL(O),H=document.createElement("a");H.href=L,H.download=`happy-balance-backup-${new Date().toISOString().split("T")[0]}.json`,document.body.appendChild(H),H.click(),document.body.removeChild(H),URL.revokeObjectURL(L),r(g,n()("settings.export_success")),r(k,!0),setTimeout(()=>{r(g,""),r(k,!1)},3e3)}function B(t){const O=t.target,L=O.files?.[0];if(!L)return;if(r(I,""),r(g,""),r(k,!1),r(p,!0),!L.name.toLowerCase().endsWith(".json")){r(I,n()("settings.import_invalid_file")),r(p,!1);return}if(L.size>10*1024*1024){r(I,n()("settings.import_file_too_large")),r(p,!1);return}const H=new FileReader;H.onload=async le=>{try{const Z=le.target?.result,K=JSON.parse(Z);if(!_(K)){r(I,n()("settings.import_invalid_format")),r(p,!1);return}r(E,K),r(v,!0),r(p,!1),r(g,n()("settings.import_success",{count:K.transactions?.length||0})),r(k,!0),r(p,!1),setTimeout(()=>{r(g,""),r(k,!1)},5e3)}catch(Z){console.error("Import error:",Z),r(I,n()("settings.import_parse_error")),r(p,!1)}},H.onerror=()=>{r(I,n()("settings.import_read_error")),r(p,!1)},H.readAsText(L),O.value=""}function _(t){return!(!t||typeof t!="object"||!Array.isArray(t.transactions)||t.settings&&typeof t.settings!="object"||t.metadata&&typeof t.metadata!="object")}async function fe(t){if(t.transactions&&Array.isArray(t.transactions)){const O=JSON.parse(localStorage.getItem("transactions")||"[]"),L=JSON.parse(localStorage.getItem("transaction-hashes")||"[]"),H=t.transactions.filter(K=>K.hash&&!L.includes(K.hash)),le=[...O,...H],Z=[...L,...H.map(K=>K.hash)];localStorage.setItem("transactions",JSON.stringify(le)),localStorage.setItem("transaction-hashes",JSON.stringify(Z))}if(t.transactionHashes&&Array.isArray(t.transactionHashes)){const O=JSON.parse(localStorage.getItem("transaction-hashes")||"[]"),L=[...new Set([...O,...t.transactionHashes])];localStorage.setItem("transaction-hashes",JSON.stringify(L))}if(t.categories&&Array.isArray(t.categories)){const L=[...JSON.parse(localStorage.getItem("categories")||"[]"),...t.categories];localStorage.setItem("categories",JSON.stringify(L))}t.settings&&(t.settings.currency&&Oe[t.settings.currency]&&(Ie(t.settings.currency),await G.updateCurrency(t.settings.currency)),t.settings.language&&h.find(O=>O.code===t.settings.language)&&(we(t.settings.language),await G.updateLanguage(t.settings.language)),t.settings.theme&&["light","dark","system"].includes(t.settings.theme)&&(Ce(t.settings.theme),await G.updateTheme(t.settings.theme)))}async function ue(){if(l(E)){r(p,!0);try{await fe(l(E)),r(g,n()("settings.import_success",{count:l(E).transactions?.length||0})),r(k,!0),setTimeout(()=>{r(g,""),r(k,!1)},5e3)}catch(t){console.error("Import error:",t),r(I,n()("settings.import_error"))}finally{r(p,!1),r(E,null)}}}function de(){r(E,null)}function he(){r(m,!0)}function be(){r(N,!0)}async function pe(){try{try{(await fetch(`${T}/seed`,{method:"POST",headers:{"Content-Type":"application/json"}})).ok||console.warn("Failed to reset data from database, falling back to localStorage reset")}catch{console.warn("API not available, proceeding with localStorage reset")}if(Le){localStorage.removeItem("categories"),localStorage.removeItem("user-preferences");const t=["transactions","transaction-hashes","theme","expense-tracker-language","expense-tracker-currency"];Object.keys(localStorage).forEach(L=>{t.includes(L)||localStorage.removeItem(L)})}await G.updateCurrency("EUR"),await G.updateLanguage("en"),await G.updateTheme("light"),Ie("EUR"),we("en"),Ce("light"),await Ye.load(),r(g,"Data has been successfully reset to defaults"),r(k,!0),setTimeout(()=>{r(g,""),r(k,!1)},3e3),setTimeout(()=>{window.location.reload()},2e3)}catch(t){console.error("Error resetting data:",t),r(I,"Failed to reset data to defaults")}}async function _e(){try{if(Le){const t=["theme","expense-tracker-language","expense-tracker-currency"];Object.keys(localStorage).forEach(L=>{t.includes(L)||localStorage.removeItem(L)})}try{(await fetch(`${T}/transactions`,{method:"DELETE",headers:{"Content-Type":"application/json"}})).ok||console.warn("Failed to delete transactions from database, but localStorage was cleared"),(await fetch(`${T}/categories`,{method:"DELETE",headers:{"Content-Type":"application/json"}})).ok||console.warn("Failed to delete categories from database, but localStorage was cleared")}catch{console.warn("API not available, but localStorage was cleared")}r(g,"All data has been successfully deleted"),r(k,!0),setTimeout(()=>{r(g,""),r(k,!1)},3e3),setTimeout(()=>{window.location.reload()},2e3)}catch(t){console.error("Error deleting data:",t),r(I,"Failed to delete all data")}}ze(async()=>{await G.load()}),ce(()=>i(),()=>{r(C,i()==="dark")}),ce(()=>l(I),()=>{l(I)&&setTimeout(()=>{r(I,"")},5e3)}),ye(),ge(),$t(d,{get isDark(){return l(C)},onToggleTheme:P,get languages(){return h},get currentLanguage(){return s()},onLanguageChange:ee,get currencyOptions(){return A},get currentCurrency(){return c()},onCurrencyChange:$,get importing(){return l(p)},onExportData:z,onImportFile:B,onResetData:be,onDeleteAllData:he,get importStatus(){return l(g)},get importError(){return l(I)},get importSuccess(){return l(k)},get pendingImportData(){return l(E)},onConfirmImport:ue,onCancelImport:de,onConfirmReset:pe,onConfirmDeleteAll:_e,get t(){return n()},get showImportModal(){return l(v)},set showImportModal(t){r(v,t)},get showDeleteAllModal(){return l(m)},set showDeleteAllModal(t){r(m,t)},get showResetModal(){return l(N)},set showResetModal(t){r(N,t)},$$legacy:!0}),ne(),f()}export{Vt as component};
